"""control_logic.py icin saf birim testleri (rclpy gerektirmez)."""

import unittest

from turtle_duvar_py.control_logic import compute_cmd, is_near_wall


class TestIsNearWall(unittest.TestCase):

    def test_center_is_safe(self):
        self.assertFalse(is_near_wall(5.5, 5.5, min_limit=1.0, max_limit=10.0))

    def test_below_min_x(self):
        self.assertTrue(is_near_wall(0.5, 5.0, min_limit=1.0, max_limit=10.0))

    def test_below_min_y(self):
        self.assertTrue(is_near_wall(5.0, 0.9, min_limit=1.0, max_limit=10.0))

    def test_above_max_x(self):
        self.assertTrue(is_near_wall(10.5, 5.0, min_limit=1.0, max_limit=10.0))

    def test_above_max_y(self):
        self.assertTrue(is_near_wall(5.0, 11.0, min_limit=1.0, max_limit=10.0))

    def test_exact_boundary_is_safe(self):
        # Odev metni "1.0'den kucuk / 10.0'dan buyuk" diyor -> sinirin
        # tam uzerinde (1.0 veya 10.0) hala guvenli kabul edilir.
        self.assertFalse(is_near_wall(1.0, 10.0, min_limit=1.0, max_limit=10.0))


class TestComputeCmd(unittest.TestCase):

    def test_goes_straight_in_center(self):
        cmd = compute_cmd(
            x=5.5, y=5.5, linear_speed=2.0, angular_speed=1.0,
            min_limit=1.0, max_limit=10.0,
        )
        self.assertEqual(cmd.linear_x, 2.0)
        self.assertEqual(cmd.angular_z, 0.0)

    def test_turns_near_wall(self):
        cmd = compute_cmd(
            x=0.5, y=5.5, linear_speed=2.0, angular_speed=1.0,
            min_limit=1.0, max_limit=10.0,
        )
        self.assertEqual(cmd.linear_x, 2.0)
        self.assertEqual(cmd.angular_z, 1.0)

    def test_respects_custom_parameters(self):
        cmd = compute_cmd(
            x=2.0, y=2.0, linear_speed=3.0, angular_speed=1.5,
            min_limit=2.5, max_limit=8.0,
        )
        # x=2.0 < min_limit=2.5 -> donmeli
        self.assertEqual(cmd.angular_z, 1.5)
        self.assertEqual(cmd.linear_x, 3.0)


if __name__ == '__main__':
    unittest.main()
