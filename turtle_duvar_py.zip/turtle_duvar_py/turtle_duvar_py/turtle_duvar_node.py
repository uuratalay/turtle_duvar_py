"""turtle_duvar: /turtle1/pose'u dinler, kaplumbagayi /turtle1/cmd_vel
uzerinden ileri surer ve sinira yaklasinca donerek yon degistirir.
Konum saniyede bir loglanir. Hiz ve sinirlar ROS2 parametresidir (bonus)."""

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose

from turtle_duvar_py.control_logic import compute_cmd


class TurtleDuvarNode(Node):

    def __init__(self) -> None:
        super().__init__('turtle_duvar')

        # Bonus: hiz ve sinir degerleri parametre
        # NOT: donus yaricapi r = linear_speed / angular_speed'tir. Sinir
        # (min_limit/max_limit) ile gercek turtlesim duvari (0 / ~11.09)
        # arasinda sadece ~1.0 birimlik bosluk var; r bu boslugun acikca
        # altinda olmali yoksa kaplumbaga donerken gercek duvara carpar.
        # 1.5/4.0 = 0.375 -> guvenli marj.
        self.declare_parameter('linear_speed', 1.5)
        self.declare_parameter('angular_speed', 4.0)
        self.declare_parameter('min_limit', 1.0)
        self.declare_parameter('max_limit', 10.0)

        self._pose: Pose | None = None

        self._cmd_pub = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)
        self._pose_sub = self.create_subscription(
            Pose, '/turtle1/pose', self._pose_callback, 10
        )
        # Pozisyonu saniyede bir logla
        self._log_timer = self.create_timer(1.0, self._log_position)

        self.get_logger().info('turtle_duvar_node baslatildi.')

    def _pose_callback(self, msg: Pose) -> None:
        self._pose = msg

        linear_speed = self.get_parameter('linear_speed').value
        angular_speed = self.get_parameter('angular_speed').value
        min_limit = self.get_parameter('min_limit').value
        max_limit = self.get_parameter('max_limit').value

        cmd = compute_cmd(
            msg.x, msg.y, linear_speed, angular_speed, min_limit, max_limit
        )

        twist = Twist()
        twist.linear.x = cmd.linear_x
        twist.angular.z = cmd.angular_z
        self._cmd_pub.publish(twist)

    def _log_position(self) -> None:
        if self._pose is None:
            return
        self.get_logger().info(
            f'Konum -> x: {self._pose.x:.2f}, y: {self._pose.y:.2f}'
        )


def main(args=None) -> None:
    rclpy.init(args=args)
    node = TurtleDuvarNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
