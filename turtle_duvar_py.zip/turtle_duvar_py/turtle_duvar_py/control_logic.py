"""Saf kontrol mantigi -- rclpy'a bagli degildir, bu yuzden ROS2 kurulu
olmayan bir ortamda bile plain `python3` ile birim testi yapilabilir.

Kural (odev metni):
  Kaplumbaga /turtle1/cmd_vel ile ileri surulur; x veya y 1.0'den kucuk
  ya da 10.0'dan buyukse donerek yon degistirir.
"""

from dataclasses import dataclass


@dataclass(frozen=True)
class Twist2D:
    linear_x: float
    angular_z: float


def is_near_wall(x: float, y: float, min_limit: float, max_limit: float) -> bool:
    """x veya y sinirin disina cikmis ya da cikmak uzereyse True doner."""
    return (
        x < min_limit or x > max_limit
        or y < min_limit or y > max_limit
    )


def compute_cmd(
    x: float,
    y: float,
    linear_speed: float,
    angular_speed: float,
    min_limit: float,
    max_limit: float,
) -> Twist2D:
    """Mevcut pose'a gore uygulanacak hiz komutunu hesaplar.

    Duvara yakin degilse: duz ileri (angular_z = 0).
    Duvara yakinsa/disariyaysa: ileri + donus (angular_z = angular_speed)
    boylece kaplumbaga donerken merkeze dogru kavis cizer.
    """
    if is_near_wall(x, y, min_limit, max_limit):
        return Twist2D(linear_x=linear_speed, angular_z=angular_speed)
    return Twist2D(linear_x=linear_speed, angular_z=0.0)
